﻿using IdentityServer4.Validation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace STSTokenServer
{
    public class UserDataClaim : ICustomTokenRequestValidator
    {
        public Task ValidateAsync(CustomTokenRequestValidationContext context)
        {
            try
            {
                var raw = context.Result.ValidatedRequest.Raw;
                if (raw.HasKeys())
                {
                    var userdata = raw.GetValues("CustomData");
                    if (userdata != null && userdata.Count() > 0)
                    {
                        foreach (var element in userdata)
                        {
                            context.Result.ValidatedRequest.ClientClaims.Add(new Claim("CustomData", element));
                        }
                    }

                    var providerdata = raw.GetValues("ProviderID");
                    if (providerdata != null && providerdata.Count() > 0)
                    {
                        foreach (var element in providerdata)
                        {
                            context.Result.ValidatedRequest.ClientClaims.Add(new Claim("ProviderID", element));
                        }
                    }

                    var documentdata = raw.GetValues("DocID");
                    if (documentdata != null && documentdata.Count() > 0)
                    {
                        foreach (var elementlist in documentdata)
                        {
                            foreach (var element in elementlist.Split(",").ToList<string>())
                            {
                                context.Result.ValidatedRequest.ClientClaims.Add(new Claim("DocID", element));
                            }

                        }
                    }

                    var accountdata = raw.GetValues("AccountID");
                    if (accountdata != null && accountdata.Count() > 0)
                    {
                        foreach (var element in accountdata)
                        {
                            context.Result.ValidatedRequest.ClientClaims.Add(new Claim("AccountID", element));
                        }
                    }
                    //var doctypedata = raw.GetValues("DocTypeID");
                    //if (doctypedata != null && doctypedata.Count() > 0)
                    //{
                    //    foreach (var element in doctypedata)
                    //    {
                    //        context.Result.ValidatedRequest.ClientClaims.Add(new Claim("DocTypeID", element));
                    //    }
                    //}
                }
            }
            catch (Exception ex)
            {

                
            }
            return Task.CompletedTask;
        }
    }
}
